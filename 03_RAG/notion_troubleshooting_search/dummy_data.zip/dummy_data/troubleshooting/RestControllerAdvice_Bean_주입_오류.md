# @RestControllerAdvice Bean 주입 오류

## 문제 상황
`@RestControllerAdvice` 클래스에서
`@Autowired`로 빈 주입 시 `NullPointerException` 발생.

## 오류 메시지
```
java.lang.NullPointerException: 
Cannot invoke method because service is null
```

## 원인
- `@RestControllerAdvice`는 Spring 초기화 순서상
  일반 `@Service` 빈보다 먼저 생성됨
- 순환 의존성 또는 초기화 순서 문제

## 해결 방법

### 방법 1. @Lazy 어노테이션 사용
```java
@RestControllerAdvice
public class GlobalExceptionHandler {

    @Lazy
    @Autowired
    private UserService userService;
}
```

### 방법 2. ApplicationContext에서 직접 꺼내기
```java
@RestControllerAdvice
public class GlobalExceptionHandler implements ApplicationContextAware {

    private ApplicationContext context;

    @Override
    public void setApplicationContext(ApplicationContext ctx) {
        this.context = ctx;
    }

    private UserService getUserService() {
        return context.getBean(UserService.class);
    }
}
```

### 방법 3. 구조 변경 (권장)
ExceptionHandler에서 Service 직접 주입 대신
필요한 로직을 별도 컴포넌트로 분리

## 결과
@Lazy 적용 후 NullPointerException 해결 확인
