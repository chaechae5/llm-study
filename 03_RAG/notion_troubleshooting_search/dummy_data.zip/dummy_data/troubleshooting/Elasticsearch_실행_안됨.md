# Elasticsearch 실행 안됨

## 문제 상황
Elasticsearch 시작 시 바로 종료되거나
`max virtual memory areas vm.max_map_count` 오류 발생.

## 오류 메시지
```
max virtual memory areas vm.max_map_count [65530] 
is too low, increase to at least [262144]
```

## 원인
Linux 시스템의 가상 메모리 설정이
Elasticsearch 최소 요구사항보다 낮음.

## 해결 방법

### 임시 적용 (재부팅 시 초기화)
```bash
sudo sysctl -w vm.max_map_count=262144
```

### 영구 적용
```bash
# /etc/sysctl.conf 파일 편집
echo "vm.max_map_count=262144" | sudo tee -a /etc/sysctl.conf

# 설정 적용
sudo sysctl -p
```

### Docker로 실행 시
```yaml
# docker-compose.yml
elasticsearch:
  image: elasticsearch:8.0.0
  environment:
    - "ES_JAVA_OPTS=-Xms512m -Xmx512m"
  ulimits:
    memlock:
      soft: -1
      hard: -1
```

## 확인 방법
```bash
# 설정값 확인
cat /proc/sys/vm/max_map_count

# Elasticsearch 상태 확인
curl http://localhost:9200/_cluster/health
```

## 결과
vm.max_map_count 설정 후 Elasticsearch 정상 실행 확인
