# MySQL ONLY_FULL_GROUP_BY 모드 오류

## 문제 상황
GROUP BY 쿼리 실행 시 아래 오류 발생.
```
Error Code: 1055
Expression #1 of SELECT list is not in GROUP BY clause 
and contains nonaggregated column
```

## 원인
MySQL 5.7 이상부터 `ONLY_FULL_GROUP_BY` 모드가 기본 활성화됨.
SELECT에 GROUP BY에 없는 컬럼 포함 시 오류 발생.

## 해결 방법

### 방법 1. 쿼리 수정 (권장)
```sql
-- 수정 전
SELECT id, name, MAX(created_at)
FROM users
GROUP BY id;

-- 수정 후
SELECT id, MAX(name), MAX(created_at)
FROM users
GROUP BY id;
```

### 방법 2. sql_mode 변경 (임시방편)
```sql
SET GLOBAL sql_mode=(
  SELECT REPLACE(@@sql_mode,'ONLY_FULL_GROUP_BY','')
);
```

### 방법 3. application.yml 설정
```yaml
spring:
  datasource:
    url: jdbc:mysql://host:3306/db?sessionVariables=sql_mode='NO_ENGINE_SUBSTITUTION'
```

## 재발 방지
쿼리 작성 시 GROUP BY 컬럼과 SELECT 컬럼 일치 여부 확인

## 결과
쿼리 수정 후 정상 실행 확인
