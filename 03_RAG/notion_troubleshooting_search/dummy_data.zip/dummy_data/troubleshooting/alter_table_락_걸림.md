# ALTER TABLE 실행 중 락 걸림

## 문제 상황
운영 DB에서 ALTER TABLE 실행 중 테이블 락이 걸려서
서비스 전체가 응답 불가 상태가 됨.

## 원인
- 대용량 테이블에 컬럼 추가 시 테이블 전체 락 발생
- 실행 중 다른 트랜잭션이 해당 테이블 접근 시도

## 해결 방법
1. 현재 실행 중인 쿼리 확인
```sql
SHOW PROCESSLIST;
```

2. 락 걸린 프로세스 강제 종료
```sql
KILL QUERY [process_id];
```

3. pt-online-schema-change 도구 활용하여 무중단 ALTER 실행
```bash
pt-online-schema-change \
  --alter "ADD COLUMN new_col VARCHAR(255)" \
  D=dbname,t=tablename \
  --execute
```

## 재발 방지
- 대용량 테이블 스키마 변경 시 pt-osc 필수 사용
- 변경 작업은 트래픽 적은 새벽 시간대 진행

## 결과
pt-osc 활용하여 무중단으로 컬럼 추가 성공
