# Jenkins & NCP 웹훅 URL 연동 오류

## 문제 상황
Jenkins에서 NCP 웹훅 URL로 요청을 보냈으나 연결이 되지 않음.
빌드 트리거가 작동하지 않아 자동 배포가 실패함.

## 원인
- NCP 보안 그룹에서 Jenkins 서버 IP가 화이트리스트에 등록되지 않음
- 웹훅 URL의 포트(8080)가 방화벽에서 차단됨

## 해결 방법
1. NCP 콘솔 → 보안 그룹 → Inbound 규칙 추가
2. Jenkins 서버 IP를 허용 IP로 등록
3. 포트 8080 허용 설정 추가
4. Jenkins에서 웹훅 URL 재등록 후 테스트 빌드 실행

## 참고
```bash
# 웹훅 테스트 명령어
curl -X POST http://your-webhook-url:8080/webhook
```

## 결과
웹훅 연동 성공 후 자동 배포 정상 작동 확인
