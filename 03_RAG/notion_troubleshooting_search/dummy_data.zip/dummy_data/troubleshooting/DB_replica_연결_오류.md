# DB Replica 연결 오류

## 문제 상황
서버 배포 후 DB replica 연결이 실패하면서 읽기 쿼리가 전부 오류 발생.
로그에 `Cannot connect to replica host` 에러 출력됨.

## 원인
- application.yml의 replica DB 호스트 주소가 잘못 설정됨
- 개발 환경 설정이 운영 환경에 그대로 배포됨

## 해결 방법
1. application-prod.yml 파일 확인
2. replica 호스트 주소 수정

```yaml
spring:
  datasource:
    replica:
      url: jdbc:mysql://prod-replica-host:3306/dbname
      username: prod_user
      password: prod_password
```

3. 서버 재배포 후 replica 연결 확인

## 재발 방지
- 환경별 설정 파일 분리 철저히 관리
- 배포 전 설정 파일 검토 체크리스트 추가

## 결과
replica 연결 정상화 및 읽기 쿼리 정상 작동 확인
