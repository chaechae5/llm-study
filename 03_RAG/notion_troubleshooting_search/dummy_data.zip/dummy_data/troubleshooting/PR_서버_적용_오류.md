# PR 서버에 적용하면서 문제 및 개선사항 정리

## 문제 상황
PR 브랜치를 서버에 배포 후 여러 문제 발생.
주로 환경 변수 누락과 DB 마이그레이션 충돌.

## 발생한 문제들

### 1. 환경 변수 누락
```
Error: REDIS_HOST environment variable is not set
```

**해결**
```bash
# .env.example 파일 기준으로 환경 변수 추가
export REDIS_HOST=localhost
export REDIS_PORT=6379
```

### 2. Flyway 마이그레이션 충돌
```
FlywayException: Found more than one migration with version 3
```

**해결**
```
migration 파일 버전 번호 중복 확인 후
V4__add_new_column.sql 로 버전 변경
```

### 3. 포트 충돌
```
Web server failed to start. Port 8080 was already in use.
```

**해결**
```bash
# 사용 중인 포트 확인 및 종료
fuser -k 8080/tcp
```

## 개선사항
- PR 배포 전 체크리스트 문서화
- 환경 변수 누락 방지를 위한 validation 로직 추가
- Flyway 버전 관리 규칙 팀 공유

## 결과
체크리스트 도입 후 PR 배포 오류 빈도 감소
