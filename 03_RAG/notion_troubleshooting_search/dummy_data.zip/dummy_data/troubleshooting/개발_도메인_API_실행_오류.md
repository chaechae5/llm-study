# 개발 도메인 API 실행 오류

## 문제 상황
개발 서버 도메인으로 API 호출 시
`ERR_CONNECTION_REFUSED` 또는 `502 Bad Gateway` 발생.

## 원인
- Nginx 설정에서 upstream 서버 주소 오류
- Spring Boot 앱이 실행되지 않은 상태
- 포트 충돌로 인한 실행 실패

## 해결 방법

### 1. 앱 실행 상태 확인
```bash
# 프로세스 확인
ps -ef | grep java

# 포트 사용 확인
lsof -i :8080
```

### 2. 앱 재실행
```bash
# 기존 프로세스 종료
kill -9 [pid]

# 앱 실행
nohup java -jar app.jar --spring.profiles.active=dev > app.log 2>&1 &
```

### 3. Nginx 설정 확인
```nginx
# /etc/nginx/sites-available/default
server {
    listen 80;
    server_name dev.example.com;

    location / {
        proxy_pass http://localhost:8080;
        proxy_set_header Host $host;
    }
}
```

### 4. Nginx 재시작
```bash
sudo nginx -t          # 설정 문법 확인
sudo systemctl restart nginx
```

### 5. 로그 확인
```bash
tail -f app.log
tail -f /var/log/nginx/error.log
```

## 결과
앱 재실행 및 Nginx 설정 수정 후 API 정상 호출 확인
