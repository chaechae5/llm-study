# Spring Boot 의존성 충돌 오류

## 문제 상황
Spring Boot 버전 업그레이드 후 빌드 시
`NoSuchMethodError` 또는 `ClassNotFoundException` 발생.

## 오류 메시지
```
java.lang.NoSuchMethodError: 
'void org.springframework.web.servlet.mvc.method.annotation
.RequestMappingHandlerAdapter.setIgnoreDefaultModelOnRedirect(boolean)'
```

## 원인
- Spring Boot 버전과 하위 라이브러리 버전 불일치
- 서로 다른 버전의 spring-webmvc가 classpath에 존재

## 해결 방법
1. 의존성 트리 확인
```bash
./gradlew dependencies | grep spring-webmvc
```

2. build.gradle에서 버전 명시적으로 통일
```groovy
dependencies {
    implementation 'org.springframework.boot:spring-boot-starter-web'
    // 버전 명시
    implementation 'org.springframework:spring-webmvc:6.0.11'
}
```

3. 충돌하는 의존성 exclude 처리
```groovy
configurations.all {
    resolutionStrategy {
        force 'org.springframework:spring-webmvc:6.0.11'
    }
}
```

## 결과
의존성 통일 후 빌드 성공 확인
