# Springdoc - Array 타입이 Swagger에서 이상하게 표시

## 문제 상황
API 응답에 List 타입 필드가 있는데
Swagger UI에서 array 타입이 올바르게 표시되지 않음.
`[string]` 대신 `string`으로 표시됨.

## 원인
- `@Schema` 어노테이션에 `implementation` 속성 누락
- Generic 타입이 Swagger에서 제대로 인식되지 않음

## 해결 방법
1. DTO에 `@Schema` 어노테이션 수정
```java
// 수정 전
@Schema(description = "태그 목록")
private List<String> tags;

// 수정 후
@Schema(description = "태그 목록", 
        type = "array",
        implementation = String.class)
private List<String> tags;
```

2. 복잡한 객체 리스트의 경우
```java
@ArraySchema(schema = @Schema(implementation = TagDto.class))
private List<TagDto> tags;
```

## 참고
springdoc-openapi 버전 2.x 이상에서는
`@ArraySchema` 사용 권장

## 결과
Swagger UI에서 array 타입 정상 표시 확인
